#ifndef floorPlanningH
#define floorPlanningH

#include "floorPlan.h"
//---------------------------------------------------------------------------


double floorPlanning(FloorPlan &fp);


#endif