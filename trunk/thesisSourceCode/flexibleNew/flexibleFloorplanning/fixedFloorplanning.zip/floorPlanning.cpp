


#include <vector>
//#include <string.h>
#include <iostream> // standard streams
#include <fstream> // file streams
#include <sstream> // string streams
#include <map>
#include "floorPlanning.h"

using namespace std;

double floorPlanning(FloorPlan &fp)
{

  double time=seconds(); 
  return time; 
}

