

//#include <vector>
//#include <string.h>
//#include <map>
//#include <stdio.h>

//#include <iostream>
//#include <fstream>

//---------------------------------------------------------------------------

#include <vector>
//#include <string.h>
#include <iostream> // standard streams
#include <fstream> // file streams
#include <sstream> // string streams
using namespace std;
#include <map>




#include "floorplan.h"

char line[100],t1[40],t2[40];

ifstream fs;

FloorPlan::FloorPlan(){
  norm_area= 1;
  norm_wire= 1;
  
}


void FloorPlan::clear(){
  Area = 0; 
}

double FloorPlan::getCost(){
  
     return (Area/norm_area);
}

float FloorPlan::getDeadSpace(){
  return 100*(Area-TotalArea)/float(Area);
}

void FloorPlan::normalize_cost(int t){
  norm_area=norm_wire=0;

  for(int i=0; i < t; i++){
    
    norm_area += Area;
   
  }
  
  norm_area /= t;
  norm_wire /= t;
  printf("normalize area=%.0f, wire=%.0f\n", norm_area, norm_wire);
}

//---------------------------------------------------------------------------
//   Read
//---------------------------------------------------------------------------

char* tail(char *str){
    str[strlen(str)-1]=0;
    return str;
}

void FloorPlan::read(char *file){
  filename = file; 
  fs.open(file);
  if(fs==NULL)
    error("unable to open file: %s",file);

  bool final=false;
  Module dummy_mod;
  for(int i=0; !fs.eof(); i++){
    // modules
    modules.push_back(dummy_mod);	// new module
    Module &mod = modules.back();
    mod.id = i;
   

    fs >> t1 >> t2;
    tail(t2);			// remove ";"
    strcpy(mod.name,t2);

    fs >> t1 >> t2;
    if(!strcmp(t2,"PARENT;"))
	final= true;
    
    // dimension
  
  }

  root_module = modules.back();
  modules.pop_back();		// exclude the parent module
  modules_N = modules.size();  
  modules_info.resize(modules_N);
  modules.resize(modules_N);

   TotalArea = 0;
  for( i=0; i < modules_N; i++)
    TotalArea += modules[i].area;

}

void FloorPlan::read_dimension(Module &mod){
    fs >> t1;
    int min_x=INT_MAX,min_y=INT_MAX,max_x=INT_MIN,max_y=INT_MIN;
    int tx,ty;
    for(int i=0; i < 4;i++){
      fs >> tx >> ty; 
      min_x=min(min_x,tx); max_x=max(max_x,tx);
      min_y=min(min_y,ty); max_y=max(max_y,ty);
    }

    mod.x      = min_x;
    mod.y      = min_y;
    mod.width  = max_x - min_x;
    mod.height = max_y - min_y;
    mod.area   = mod.width * mod.height;
    fs >> t1 >> t2;
}


//---------------------------------------------------------------------------
//   Modules Information
//---------------------------------------------------------------------------

string query_map(map<string,int> M,int value){
  for(map<string,int>::iterator p=M.begin(); p != M.end(); p++){
    if(p->second == value)
      return p->first;
  }
  return "";
}

void FloorPlan::show_modules()
{
  for(int i=0; i < modules.size();i++){
    cout << "Module: " << modules[i].name << endl;
    cout << "  Width = " << modules[i].width;
    cout << "  Height= " << modules[i].height << endl;
    cout << "  Area  = " << modules[i].area << endl;
//    cout << modules[i].pins.size() << " Pins:\n";
//    for(int j=0; j < modules[i].pins.size(); j++){
//      cout << query_map(net_table,modules[i].pins[j].net) << " ";
//      cout << modules[i].pins[j].x << " " << modules[i].pins[j].y << endl;
//    }
  }
}

void FloorPlan::list_information(){

  string info = filename + ".info"   ;
  ofstream of(info.c_str());
  
  of << modules_N << " " << Width << " " << Height << endl;
  for(int i=0; i < modules_N; i++){
    of << modules_info[i].x  << " " << modules_info[i].rx  << " ";
    of << modules_info[i].y << " " << modules_info[i].ry << endl;
  }
  of << endl;

  
  cout << "Num of Module  = " << modules_N << endl;
  cout << "Height         = " << Height*1e-3 << endl;
  cout << "Width          = " << Width*1e-3 << endl;
  cout << "Area           = " << Area*1e-6 << endl;
  cout << "Total Area     = " << TotalArea*1e-6 << endl;
  printf( "Dead Space     = %.2f\n", getDeadSpace());
}

//---------------------------------------------------------------------------
//   Auxilliary Functions
//---------------------------------------------------------------------------

void error(char *msg,char *msg2){
  printf(msg,msg2);
  cout << endl;
  throw 1;
}


double seconds(){
   /*rusage time;
   getrusage(RUSAGE_SELF,&time);
   return (double)(1.0*time.ru_utime.tv_sec+0.000001*time.ru_utime.tv_usec); */ return 1;
}


int min(int a,int b){
	return a>b?b:a;
}
int max(int a,int b){
 return a>b?a:b;
}

