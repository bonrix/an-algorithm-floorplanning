// fixedFloorplanning.cpp : Defines the entry point for the console application.
//

#include <iostream.h>     
#include "stdio.h"
#include <string.h>
#include <time.h>
#include "floorPlanning.h"
#include <stdio.h>

/*int main(int argc, char* argv[])
{
	printf("Hello World!\n");
	return 0;
}*/

int main(int argc,char **argv)
{
   char filename[80],outfile[80]="";
  
double last_time  = 1 ;

   if(argc<=1){
     printf("Usage: fixedFloorplanning <inputFileName> <outputFileName>  \n");
     return 0;
   }else{
     int argi=1;
     if(argi < argc) strcpy(filename, argv[argi++]);
     if(argi < argc) strcpy(outfile, argv[argi++]);
   }

   try{
     double time = seconds();
      FloorPlan fp;
     fp.read(filename);
     //fp.show_modules();
  
     // double last_time =  SA_Floorplan(fp, times, local, term_temp);
     //Random_Floorplan(fp,times);
     fp.list_information();

     { // log performance and quality
       if(strlen(outfile)==0)
         strcpy(outfile,strcat(filename,".res"));

       last_time = last_time - time;
       printf("CPU time       = %.2f\n",seconds()-time);
       printf("Last CPU time  = %.2f\n",last_time);
       FILE *fs= fopen(outfile,"a+");
       

       fprintf(fs,"CPU= %.2f, Cost= %.6f, Area= %.0f, Dead=%.4f ", last_time, float(fp.getCost()),  float(fp.getArea()), float(fp.getDeadSpace()));
      // fprintf(fs," :%d %d %.0f \n", times, local, avg_ratio);
       fclose(fs);
     }

   }catch(...){}
   return 1;
}
