#ifndef floorPlanH
#define floorPlanH

//---------------------------------------------------------------------------

//#include <cstdio>
//---------------------------------------------------------------------------
#include <vector>
//#include <string.h>
#include <iostream> // standard streams
#include <fstream> // file streams
#include <sstream> // string streams
using namespace std;
#include <map>


enum Module_Type { MT_Hard, MT_Soft};

struct Module{
  int id;
  char name[20];
  int width,height;
  int x,y;
  int area;
  Module_Type type;
};

typedef vector<Module> Modules;

struct Module_Info{
  bool rotate, flip;
  int x,y;
  int rx,ry;
};

typedef vector<Module_Info> Modules_Info;

class FloorPlan{
  public:
    FloorPlan();
    void read(char*);
  
  
    double getCost();    

    int    size()         { return modules_N; }
    double getTotalArea() { return TotalArea; }
    double getArea()      { return Area;      }
    double getWidth()     { return Width;     }
    double getHeight()    { return Height;    }
    float  getDeadSpace();

    // information
    void list_information();
    void show_modules();    
    void normalize_cost(int);
    
  protected:
    void clear();
   
    double Area;
    double Width,Height;
   
    double TotalArea;
    
    int modules_N;    
    Modules modules;
    Module  root_module;
    Modules_Info modules_info;    
   
    double norm_area, norm_wire;
    
    
  private:
    void read_dimension(Module&);
    string filename; 

};


void error(char *msg,char *msg2="");
double seconds();
int min(int x,int y);
int max(int x,int y);

      
#endif
